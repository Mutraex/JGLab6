

/**
 *
 * @author Mutraex
 */
public class Manager extends ResponsibilityDecorator{
    public Manager(){
        super.responsibility="Manager";
    }
}
