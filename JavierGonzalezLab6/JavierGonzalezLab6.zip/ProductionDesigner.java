

/**
 *
 * @author Mutraex
 */
public class ProductionDesigner extends ResponsibilityDecorator{
    public ProductionDesigner(){
        super.responsibility="ProductionDesigner";
    }
}
