
/**
 *
 * @author Mutraex
 */
public class Recruiter extends ResponsibilityDecorator{
    public Recruiter(){
        super.responsibility="Recruiter";
    }
}
