/**
 *
 * @author Mutraex
 */
public class CommunityLiaison extends ResponsibilityDecorator{
    public CommunityLiaison(){
        super.responsibility="CommunityLiaison";
    }
}
