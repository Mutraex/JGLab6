
/**
 *
 * @author Mutraex
 */
public class SalariedEmployee extends Employee {
    public SalariedEmployee(String ln){
        super(ln);
    }
}
